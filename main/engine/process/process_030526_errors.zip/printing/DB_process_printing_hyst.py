# main/engine/process/printing/DB_process_printing_hyst.py

import math
import logging
import numpy as np
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from .DB_process_printing_utils import (
    _safe_get,
    _fmt_time,
    _line,
    _print_cfg,
)
from main.engine.process.printing.DB_process_SectionLogger import get_section_logger

logger = logging.getLogger(__name__)

# ======================================================================================
# PHASE 1: MODULE-LEVEL TRACKER
# - Printing module owns this for now (simple + low-risk)
# - Phase 2: pass tracker from orchestrator for cleaner state management
# ======================================================================================

_HYST_TRACKER: Dict[str, Any] = {
    "episode_start_ts": None,
    "episode_pair": None,
    "last_primary_flip_ts": None,
}


# ======================================================================================
# PUBLIC EXPORTS (for DB_process_calc / DB_process_trend later)
# ======================================================================================

def get_hyst_tracker() -> Dict[str, Any]:
    """Phase 1: allow other modules to read tracker if needed."""
    return _HYST_TRACKER


# ======================================================================================
# SMALL NUMERIC HELPERS
# ======================================================================================

def _sign(x: float, eps: float = 1e-12) -> int:
    if x > eps:
        return 1
    if x < -eps:
        return -1
    return 0


def _tail_preview(label: str, arr: np.ndarray, n: int = 10) -> str:
    """Debug helper to show last n values of a diff series."""
    if arr.size == 0:
        return f"{label}=<empty>"
    tail = arr[-n:] if arr.size >= n else arr
    return f"{label}=[" + ", ".join(f"{x:+.6f}" for x in tail) + "]"


def _mad(arr: np.ndarray) -> float:
    if arr.size == 0:
        return 0.0
    med = np.median(arr)
    return float(np.median(np.abs(arr - med)) + 1e-12)


def _percentile(arr: np.ndarray, p: float) -> float:
    if arr.size == 0:
        return 0.0
    return float(np.percentile(arr, p))


def _compute_slope(ts: List[datetime], vals: np.ndarray) -> float:
    """Simple linear slope vs seconds. vals may contain NaN (caller should pre-filter)."""
    if len(ts) < 5:
        return 0.0
    x = np.array([(t - ts[0]).total_seconds() for t in ts], dtype=float)
    y = vals.astype(float)
    if not np.isfinite(y).any():
        return 0.0
    # Filter NaNs
    m = np.isfinite(y)
    if m.sum() < 5:
        return 0.0
    x2 = x[m]
    y2 = y[m]
    try:
        return float(np.polyfit(x2, y2, 1)[0])
    except Exception:
        return 0.0


def _compute_accel(ts: List[datetime], vals: np.ndarray) -> float:
    """
    Quadratic acceleration vs seconds (2nd derivative).
    Uses y = a*x^2 + b*x + c => y'' = 2a.
    vals may contain NaN (caller may pass unfiltered).
    """
    if len(ts) < 7:
        return 0.0
    x = np.array([(t - ts[0]).total_seconds() for t in ts], dtype=float)
    y = vals.astype(float)
    if not np.isfinite(y).any():
        return 0.0
    m = np.isfinite(y)
    if m.sum() < 7:
        return 0.0
    x2 = x[m]
    y2 = y[m]
    try:
        a = float(np.polyfit(x2, y2, 2)[0])
        return float(2.0 * a)
    except Exception:
        return 0.0


def _find_last_sign_flip(ts: List[datetime], vals: np.ndarray) -> Optional[datetime]:
    """Find most recent index where sign changes between two adjacent non-zero signs."""
    if len(ts) < 3 or vals.size < 3:
        return None
    signs = np.array([_sign(v) for v in vals], dtype=int)
    for i in range(len(signs) - 1, 0, -1):
        a = signs[i - 1]
        b = signs[i]
        if a != 0 and b != 0 and a != b:
            return ts[i]
    return None


def _nearest_align(
        base_ts: List[datetime],
        other_ts: List[datetime],
        other_vals: np.ndarray,
        tol_seconds: float = 3.0,
) -> np.ndarray:
    """
    Nearest neighbor alignment (Phase 1).
    Returns array aligned to base_ts; NaN if no match within tolerance.
    """
    out = np.full(len(base_ts), np.nan, dtype=float)
    if len(base_ts) == 0 or len(other_ts) == 0:
        return out

    j = 0
    for i, t in enumerate(base_ts):
        best_k = None
        best_dt = None

        # Move j forward while other_ts[j] is behind t (small optimization)
        while j + 1 < len(other_ts) and other_ts[j + 1] <= t:
            j += 1

        # Check around j (j and j+1) for nearest
        for k in (j, j + 1):
            if 0 <= k < len(other_ts):
                dt = abs((other_ts[k] - t).total_seconds())
                if best_dt is None or dt < best_dt:
                    best_dt = dt
                    best_k = k

        if best_k is not None and best_dt is not None and best_dt <= tol_seconds:
            out[i] = float(other_vals[best_k])

    return out


# ======================================================================================
# CORE FEATURE BUILDER (NO TREND DECISION)
# ======================================================================================

def compute_hysteresis_features(
    per_sigma_hist: dict,
    decision_dt: datetime,
    lookback_seconds: float = 3600.0,
    tail_seconds: float = 120.0,
    align_tol_seconds: float = 3.0,
) -> dict:
    """
    Hysteresis fan-stack feature builder.

    Key debug addition (your request):
      stacks["S1"]["diff_tails"] = {
         "d38_53": [... last N ...],
         "d53_68": [...],
         "d68_83": [...],
      }

    If crosses are reported but these tails do NOT change sign, your cross logic is wrong.
    If these tails flip sign like crazy, your alignment/time-order is wrong.
    """

    # ----------------------------
    # helpers (local)
    # ----------------------------
    def _to_sorted_series(sig: int):
        raw = per_sigma_hist.get(sig) or []
        ts = []
        vals = []

        if isinstance(raw, dict):
            t0 = raw.get("ts") or raw.get("timestamps") or []
            v0 = raw.get("vals") or raw.get("values") or []
            n = min(len(t0), len(v0))
            ts = list(t0[:n])
            vals = list(v0[:n])

        elif isinstance(raw, list):
            if raw and isinstance(raw[0], dict):
                for r in raw:
                    t = r.get("ts") or r.get("timestamp")
                    v = r.get("val") or r.get("value")
                    if t is not None and v is not None:
                        ts.append(t)
                        vals.append(v)
            else:
                for item in raw:
                    if isinstance(item, (tuple, list)) and len(item) >= 2:
                        ts.append(item[0])
                        vals.append(item[1])

        def _ts_to_float(x):
            if isinstance(x, (int, float)):
                return float(x)
            if isinstance(x, datetime):
                return x.timestamp()
            try:
                return datetime.fromisoformat(str(x)).timestamp()
            except Exception:
                return None

        out = []
        for t, v in zip(ts, vals):
            tf = _ts_to_float(t)
            if tf is None:
                continue
            try:
                vf = float(v)
            except Exception:
                continue
            out.append((tf, vf))

        out.sort(key=lambda z: z[0])
        if not out:
            return [], []
        t_sorted = [a for a, _ in out]
        v_sorted = [b for _, b in out]
        return t_sorted, v_sorted

    def _clip_window(ts, vals, t_start, t_end):
        if not ts:
            return [], []
        i0 = 0
        while i0 < len(ts) and ts[i0] < t_start:
            i0 += 1
        i1 = len(ts) - 1
        while i1 >= 0 and ts[i1] > t_end:
            i1 -= 1
        if i1 < i0:
            return [], []
        return ts[i0:i1 + 1], vals[i0:i1 + 1]

    def _align_by_time(sig_list, t_end, window_sec, tol_sec):
        """
        Build a common time grid by taking the sigma with the densest window,
        then for each base time pick closest sample in each sigma within tol_sec.
        Drops times where any sigma can't align.
        """
        tails = {}
        counts = {}
        t_start = t_end - float(window_sec)

        for s in sig_list:
            ts, vals = _to_sorted_series(s)
            ts, vals = _clip_window(ts, vals, t_start, t_end)
            tails[s] = (ts, vals)
            counts[s] = len(ts)

        if any(counts[s] == 0 for s in sig_list):
            return {}, []

        base_sig = max(sig_list, key=lambda s: counts[s])
        base_ts = tails[base_sig][0]

        aligned = {s: [] for s in sig_list}
        grid_ts = []
        idx = {s: 0 for s in sig_list}

        for t in base_ts:
            ok = True
            picked = {}

            for s in sig_list:
                ts, vals = tails[s]
                j = idx[s]
                while j < len(ts) and ts[j] < t:
                    j += 1
                idx[s] = j

                cand = []
                if 0 <= j - 1 < len(ts):
                    cand.append((abs(ts[j - 1] - t), vals[j - 1]))
                if 0 <= j < len(ts):
                    cand.append((abs(ts[j] - t), vals[j]))
                if not cand:
                    ok = False
                    break

                cand.sort(key=lambda z: z[0])
                dt, vpick = cand[0]
                if dt > tol_sec:
                    ok = False
                    break
                picked[s] = float(vpick)

            if not ok:
                continue

            grid_ts.append(float(t))
            for s in sig_list:
                aligned[s].append(picked[s])

        if not grid_ts:
            return {}, []
        return aligned, grid_ts

    def _diff(a, b):
        return [x - y for x, y in zip(a, b)]

    def _sign_deadband(x, eps):
        if x > eps:
            return 1
        if x < -eps:
            return -1
        return 0

    def _count_sign_flips(series, eps=0.05):
        signs = [_sign_deadband(v, eps) for v in series]
        last = 0
        flips = 0
        last_eff = 0
        for s in signs:
            if s == 0:
                continue
            last_eff = s
            if last == 0:
                last = s
                continue
            if s != last:
                flips += 1
                last = s
        return flips, (last_eff if last_eff != 0 else last), signs

    def _percentile(sorted_vals, p):
        if not sorted_vals:
            return 0.0
        if p <= 0:
            return float(sorted_vals[0])
        if p >= 100:
            return float(sorted_vals[-1])
        k = (len(sorted_vals) - 1) * (p / 100.0)
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return float(sorted_vals[int(k)])
        d0 = sorted_vals[int(f)] * (c - k)
        d1 = sorted_vals[int(c)] * (k - f)
        return float(d0 + d1)

    def _pct_rank(sorted_vals, x):
        if not sorted_vals:
            return 0.0
        # percent of values <= x
        n = len(sorted_vals)
        lo = 0
        hi = n
        while lo < hi:
            mid = (lo + hi) // 2
            if sorted_vals[mid] <= x:
                lo = mid + 1
            else:
                hi = mid
        return 100.0 * (lo / n)

    def _lin_slope(ts, ys):
        # simple slope (least squares)
        n = len(ts)
        if n < 2:
            return 0.0
        t_mean = sum(ts) / n
        y_mean = sum(ys) / n
        num = sum((ts[i] - t_mean) * (ys[i] - y_mean) for i in range(n))
        den = sum((ts[i] - t_mean) ** 2 for i in range(n))
        return 0.0 if den == 0 else float(num / den)

    def _dominance(sig_vals_last):
        """
        dom = (max - min) / (sum abs pairwise diffs + eps)  (bounded-ish)
        """
        vals = list(sig_vals_last.values())
        if len(vals) < 2:
            return 0.0
        mx = max(vals)
        mn = min(vals)
        pair = 0.0
        for i in range(len(vals)):
            for j in range(i + 1, len(vals)):
                pair += abs(vals[i] - vals[j])
        return float((mx - mn) / (pair + 1e-12))

    # ----------------------------
    # stacks
    # ----------------------------
    S0 = [23, 38, 53, 68, 83]
    S1 = [38, 53, 68, 83]
    S2 = [53, 68, 83]
    S3 = [68, 83]

    t_end = float(decision_dt.timestamp())

    aligned_S0, grid_S0 = _align_by_time(S0, t_end, tail_seconds, align_tol_seconds)
    aligned_S1, grid_S1 = _align_by_time(S1, t_end, tail_seconds, align_tol_seconds)
    aligned_S2, grid_S2 = _align_by_time(S2, t_end, tail_seconds, align_tol_seconds)
    aligned_S3, grid_S3 = _align_by_time(S3, t_end, tail_seconds, align_tol_seconds)

    if not aligned_S1 or len(grid_S1) < 10:
        return {"meta": {"skipped": True, "skip_reason": "insufficient_aligned_tail"}}

    # Episode (38,83) from S1
    d38_83 = _diff(aligned_S1[38], aligned_S1[83])
    flips_38_83, sign_38_83, _ = _count_sign_flips(d38_83, eps=0.05)

    # last cross ts estimate
    last_cross_ts = None
    eps = 0.05
    sgn = [_sign_deadband(v, eps) for v in d38_83]
    cur = 0
    for k in range(len(sgn) - 1, -1, -1):
        if sgn[k] != 0:
            cur = sgn[k]
            break
    if cur != 0:
        for k in range(len(sgn) - 2, -1, -1):
            if sgn[k] == 0:
                continue
            if sgn[k] != cur:
                last_cross_ts = datetime.fromtimestamp(grid_S1[k + 1])
                break

    elapsed_s = None
    stage = "IN_PROGRESS"
    if last_cross_ts is not None:
        elapsed_s = (decision_dt - last_cross_ts).total_seconds()
        if elapsed_s >= tail_seconds:
            stage = "COMPLETE"

    episode = {
        "pair_used": (38, 83),
        "mode": "DEFAULT",
        "start_ts": last_cross_ts,
        "last_cross_ts": last_cross_ts,
        "elapsed_seconds": float(elapsed_s) if elapsed_s is not None else None,
        "stage": stage,
        "d_now": float(d38_83[-1]),
        "sign_now": int(sign_38_83),
        "flip_count_tail": int(flips_38_83),
    }

    # Probe (23,83) from S0
    probe = {}
    if aligned_S0 and len(grid_S0) >= 10:
        d23_83 = _diff(aligned_S0[23], aligned_S0[83])
        flips_23_83, sign_23_83, _ = _count_sign_flips(d23_83, eps=0.05)
        tail_n = min(10, len(d23_83))
        if tail_n >= 2:
            dy = abs(d23_83[-1] - d23_83[-tail_n])
            dt = max(1e-9, grid_S0[-1] - grid_S0[-tail_n])
            d_abs_slope_tail = dy / dt
        else:
            d_abs_slope_tail = 0.0

        probe = {
            "pair_used": (23, 83),
            "d_now": float(d23_83[-1]),
            "sign_now": int(sign_23_83),
            "flip_watch": int(flips_23_83),
            "fast_collapse": 0,
            "d_abs_slope_tail": float(d_abs_slope_tail),
        }
    else:
        probe = {
            "pair_used": (23, 83),
            "d_now": 0.0,
            "sign_now": 0,
            "flip_watch": 0,
            "fast_collapse": 0,
            "d_abs_slope_tail": 0.0,
        }

    # ETA
    if elapsed_s is None:
        eta_s = float(tail_seconds)
        eta_src = "S1"
    else:
        eta_s = max(0.0, float(tail_seconds) - float(elapsed_s))
        eta_src = "S1"
    eta = {"eta_seconds": float(eta_s), "source": eta_src}

    def _stack_block(name, sigs, aligned, grid):
        if not aligned or len(grid) < 10:
            return {"sigmas": sigs, "skipped": True}

        # last values
        last_vals = {s: float(aligned[s][-1]) for s in sigs}

        # leader/trailer in terms of value (not sigma id)
        leader_sig = max(last_vals, key=lambda s: last_vals[s])
        trailer_sig = min(last_vals, key=lambda s: last_vals[s])

        W_now = float(last_vals[leader_sig] - last_vals[trailer_sig])

        # midline slope normalized by last price
        mid_series = [sum(aligned[s][i] for s in sigs) / len(sigs) for i in range(len(grid))]
        m = _lin_slope(grid, mid_series)  # units: price/sec
        scale = max(1.0, abs(mid_series[-1]))
        m_norm = float(m / scale)

        # order quality: are values monotonic with sigma (increasing or decreasing)?
        # increasing with sigma = "bear order" (larger sigma higher value)
        # decreasing with sigma = "bull order"
        inc_good = 0
        dec_good = 0
        total = 0
        for i in range(len(sigs) - 1):
            a = aligned[sigs[i]][-1]
            b = aligned[sigs[i + 1]][-1]
            if b >= a:
                inc_good += 1
            if b <= a:
                dec_good += 1
            total += 1
        inc_ratio = inc_good / total if total else 0.0
        dec_ratio = dec_good / total if total else 0.0
        eff_order = float(max(inc_ratio, dec_ratio))
        order_bear = float(inc_ratio >= dec_ratio)
        order_bull = float(dec_ratio > inc_ratio)

        # crosses: sign flips in adjacent diffs over tail window
        eps_cross = 0.05
        crosses = {}
        cross_count = 0

        # Also compute dW and ddW metrics for geometry (normalized)
        # Width series over tail
        width_series = []
        for i in range(len(grid)):
            vals_i = [aligned[s][i] for s in sigs]
            width_series.append(float(max(vals_i) - min(vals_i)))

        # dW = change in width over tail; ddW = change in dW (approx)
        dW = width_series[-1] - width_series[0]
        # a simple 2-point acceleration using midpoint
        mid_i = len(width_series) // 2
        dW_1 = width_series[mid_i] - width_series[0]
        dW_2 = width_series[-1] - width_series[mid_i]
        ddW = (dW_2 - dW_1)

        dW_scale = max(1e-9, abs(width_series[-1]) + abs(width_series[0]))
        dW_norm = float(dW / dW_scale)

        # FIX: use dW_scale (not ddW_scale) and math.isfinite
        dW_norm = float(dW / (dW_scale + 1e-12)) if np.isfinite(dW_scale) else 0.0

        # curvature proxy for midline: second-diff of last 3 mid points (normalized)
        if len(mid_series) >= 3:
            m2 = (mid_series[-1] - 2.0 * mid_series[-2] + mid_series[-3])
            m2_norm = float(m2 / (abs(mid_series[-1]) + 1e-9))
        else:
            m2_norm = 0.0

        # Adjacent diffs series for cross detection
        for i in range(len(sigs) - 1):
            a = sigs[i]
            b = sigs[i + 1]
            d_ab = _diff(aligned[a], aligned[b])
            flips, _, _ = _count_sign_flips(d_ab, eps=eps_cross)
            # record "1" if any sign flip occurred in tail
            crosses[f"{a}-{b}"] = int(flips > 0)
            cross_count += int(flips > 0)

        cross_rate = float(cross_count / max(1, (len(sigs) - 1)))

        # baseline width percentile (use lookback aligned window)
        aligned_base, grid_base = _align_by_time(sigs, t_end, lookback_seconds, align_tol_seconds)
        if aligned_base and len(grid_base) >= 10:
            base_widths = []
            for i in range(len(grid_base)):
                vals_i = [aligned_base[s][i] for s in sigs]
                base_widths.append(float(max(vals_i) - min(vals_i)))
            base_widths.sort()
            W_p75 = _percentile(base_widths, 75)
            W_pct = _pct_rank(base_widths, W_now)
            # width ratio (vs p75)
            W_ratio = float(W_now / (W_p75 + 1e-9))
            # z-ish score using IQR-ish
            W_p25 = _percentile(base_widths, 25)
            iqr = max(1e-9, (W_p75 - W_p25))
            W_z = float((W_now - W_p75) / iqr)
        else:
            W_p75 = 0.0
            W_pct = 0.0
            W_ratio = 0.0
            W_z = 0.0

        block = {
            "sigmas": sigs,
            "m_norm": float(m_norm),
            "W_now": float(W_now),
            "W_p75": float(W_p75),
            "W_pct": float(W_pct),
            "W_ratio": float(W_ratio),
            "W_z": float(W_z),
            "dW_norm": float(dW_norm),
            "ddW_norm": float(ddW_norm),
            "m2_norm": float(m2_norm),
            "eff_order": float(eff_order),
            "order_bull": float(order_bull),
            "order_bear": float(order_bear),
            "cross_rate": float(cross_rate),
            "crosses": crosses,
            "dom": float(_dominance(last_vals)),
            "leader": f"{leader_sig}->{trailer_sig}",
        }
        return block

    stacks = {
        "S0": _stack_block("S0", S0, aligned_S0, grid_S0),
        "S1": _stack_block("S1", S1, aligned_S1, grid_S1),
        "S2": _stack_block("S2", S2, aligned_S2, grid_S2),
        "S3": _stack_block("S3", S3, aligned_S3, grid_S3),
    }

    # ---------------------------------------------------------
    # YOUR ultra-targeted debug tails (inside S1, before crosses)
    # ---------------------------------------------------------
    # We store them so the logger can print them right after S1 lines.
    def _tail(series, n=10):
        n = min(int(n), len(series))
        return [float(x) for x in series[-n:]]

    # aligned_S1 has 38,53,68,83
    d38_53 = _diff(aligned_S1[38], aligned_S1[53])
    d53_68 = _diff(aligned_S1[53], aligned_S1[68])
    d68_83 = _diff(aligned_S1[68], aligned_S1[83])

    stacks["S1"]["diff_tails"] = {
        "d38_53": _tail(d38_53, n=10),
        "d53_68": _tail(d53_68, n=10),
        "d68_83": _tail(d68_83, n=10),
    }

    # metadata
    meta = {
        "tail_seconds": float(tail_seconds),
        "baseline_seconds": float(lookback_seconds),
        "align_tol_seconds": float(align_tol_seconds),
    }

    return {
        "meta": meta,
        "episode": episode,
        "probe": probe,
        "eta": eta,
        "stacks": stacks,
    }


# ======================================================================================
# PRINTING ENTRYPOINT (LOG-ONLY)
# ======================================================================================

def print_hysteresis_fan_stack(
        timing: Any = None,
        windows: Any = None,
        decision_dt: Optional[datetime] = None,
        catalog: Any = None,
        config: Any = None,
        **_kwargs,
) -> Dict[str, Any]:
    """
    Logging-only printer.
    Returns hyst_obj features for downstream trend/calc code (but does not decide trend).
    """

    if config is None:
        config = {}

    p = _print_cfg(config)
    hcfg = p.get("HYSTERESIS", {}) if isinstance(p.get("HYSTERESIS", {}), dict) else {}
    enabled = bool(hcfg.get("ENABLED", True))
    # Legacy fallback
    if not enabled and not bool(config.get("LOG_HYSTERESIS", True)):
        return {}

    on_header = bool((hcfg.get("HEADER", {}) if isinstance(hcfg.get("HEADER", {}), dict) else {}).get("ENABLED", True))
    on_episode = bool((hcfg.get("EPISODE", {}) if isinstance(hcfg.get("EPISODE", {}), dict) else {}).get("ENABLED", True))
    on_probe = bool((hcfg.get("PROBE", {}) if isinstance(hcfg.get("PROBE", {}), dict) else {}).get("ENABLED", True))
    on_eta = bool((hcfg.get("ETA", {}) if isinstance(hcfg.get("ETA", {}), dict) else {}).get("ENABLED", True))
    on_ladder = bool((hcfg.get("LADDER", {}) if isinstance(hcfg.get("LADDER", {}), dict) else {}).get("ENABLED", True))
    on_debug = bool((hcfg.get("DEBUG", {}) if isinstance(hcfg.get("DEBUG", {}), dict) else {}).get("ENABLED", False))

    slog = get_section_logger(logger, config)

    if decision_dt is None:
        decision_dt = datetime.now()

    per_sigma_hist = _safe_get(catalog, "per_sigma_hist", default={})
    if not per_sigma_hist:
        return {"meta": {"skipped": True, "skip_reason": "no_sigma_data"}}

    hyst = compute_hysteresis_features(
        per_sigma_hist=per_sigma_hist,
        decision_dt=decision_dt,
        lookback_seconds=3600,
        tail_seconds=120,
        align_tol_seconds=3.0,
    )

    if hyst.get("meta", {}).get("skipped"):
        return hyst

    # ----------------------------------------------------------------------------------
    # LOG BLOCK (matches the layout we designed)
    # ----------------------------------------------------------------------------------
    ep = hyst["episode"]
    pr = hyst["probe"]
    eta = hyst["eta"]
    stacks = hyst["stacks"]

    if on_header:
        slog.HYST_HEADER(_line("=", 155))
        slog.HYST_HEADER("HYSTERESIS FAN STACK (method_hyster_v1.0)")
        slog.HYST_HEADER(_line("-", 155))

    if on_episode:
        slog.HYST_EPISODE(
            f"[hyst_episode] decision_time={_fmt_time(decision_dt)} | "
            f"pair=({ep['pair_used'][0]},{ep['pair_used'][1]}) | "
            f"start={_fmt_time(ep['start_ts']) if ep['start_ts'] else 'NONE'} | "
            f"elapsed={(ep['elapsed_seconds'] if ep['elapsed_seconds'] is not None else 0.0):.1f}s | "
            f"stage={ep['stage']}"
        )
        slog.HYST_EPISODE(
            f"[hyst_primary] d{ep['pair_used'][0]}_{ep['pair_used'][1]} now={ep['d_now']:+.6f} | "
            f"sign={ep['sign_now']} | "
            f"last_cross={_fmt_time(ep['last_cross_ts']) if ep['last_cross_ts'] else 'NONE'} | "
            f"lookback=60m | mode={ep['mode']}"
        )

    if on_probe:
        slog.HYST_PROBE(
            f"[hyst_probe] pair=(23,83) | d23_83 now={pr['d_now']:+.6f} | "
            f"sign={pr['sign_now']} | flip_watch={int(pr['flip_watch'])} | "
            f"fast_collapse={int(pr['fast_collapse'])} | d_abs_slope_tail={pr['d_abs_slope_tail']:+.6f}"
        )

    if eta.get("eta_to_end_seconds") is not None:
        slog.HYST_ETA(
            f"[hyst_eta] eta={eta['eta_to_end_seconds']:.1f}s (~{eta['eta_to_end_seconds'] / 300.0:.2f} epochs) | "
            f"source={eta.get('source_stack')}"
        )

    if on_ladder:
        for sid in ["S0", "S1", "S2", "S3"]:
            lm = stacks.get(sid)
            if not lm:
                continue
            sigs = ",".join(map(str, lm["sigmas"]))
            W_pct = lm["W_pct"]
            W_pct_s = "nan" if not np.isfinite(W_pct) else f"{int(round(W_pct)):>3d}"
            slog.HYST_LADDER(
                f"  [hyst_{sid}] sigmas={sigs:<14} | "
                f"m_norm={lm['m_norm']:+.3f} | "
                f"W_pct={W_pct_s} | "
                f"dW_norm={lm['dW_norm']:+.3f} | "
                f"eff_order={lm['eff_order']:.2f} | "
                f"cross={lm['cross_rate']:.2f}/m"
            )

            # ---- appended GEOM line (same section: obeys slog.HYST_LADDER toggles)
            W_now_s = "nan" if not np.isfinite(lm.get("W_now", float("nan"))) else f"{lm['W_now']:.4f}"
            W_z_s = "nan" if not np.isfinite(lm.get("W_z", float("nan"))) else f"{lm['W_z']:+.2f}"
            W_ratio_s = "nan" if not np.isfinite(lm.get("W_ratio", float("nan"))) else f"{lm['W_ratio']:.2f}"
            ddW_s = f"{lm.get('ddW_norm', 0.0):+.3f}"
            dom_s = f"{lm.get('dom', 0.0):.2f}"
            lead_max = lm.get("leader_max_sigma")
            lead_min = lm.get("leader_min_sigma")
            leader_s = f"{lead_max}->{lead_min}" if (lead_max is not None and lead_min is not None) else "NONE"

            # cross pair breakdown (only show pairs with crossings)
            cross_pairs = lm.get("cross_pairs") or {}
            parts = []
            for k, v in cross_pairs.items():
                try:
                    c = int(v.get("count", 0))
                except Exception:
                    c = 0
                if c > 0:
                    parts.append(f"{k}:{c}")
            cross_pairs_s = ",".join(parts) if parts else "none"

            slog.HYST_LADDER(
                f"  [hyst_{sid}_GEOM] "
                f"W_now={W_now_s} | W_z={W_z_s} | W_ratio={W_ratio_s} | "
                f"ddW_norm={ddW_s} | m2_norm={lm.get('m2_norm', 0.0):+.3f} | "
                f"dom={dom_s} | leader={leader_s} | crosses={cross_pairs_s}"
            )

    if on_debug:
        slog.HYST_DEBUG(
            f"  [hyst_dbg] tail={hyst['meta']['tail_window_seconds']}s | "
            f"baseline={hyst['meta']['baseline_window_seconds']}s | "
            f"align_tol={hyst['meta']['align_tol_seconds']:.1f}s"
        )

    slog.HYST_HEADER(_line("-", 155))

    return hyst