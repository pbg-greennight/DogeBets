# Locked Method v273

This bundle preserves the final locked offline comparison state from the Bear-side rescue branch.

## Final ranking
1. Winner: Bear-only RuleB + Window +/-1 + |hinge| >= 0.18
2. Fallback: Bear-only RuleB + Center Soft
3. Candidate: Bear-only RuleB + Window +/-1
4. Safe reference: Bear-only RuleB + Core A
5. Baseline: v2_2 base

## Winner definition
Apply a Bear-side neutralizer only when all of the following are true:
- Base prediction is Bear
- RuleB raw warning is active
- PM1 window support is active
- abs(hinge_torsion) >= 0.18

The action is to convert the Bear prediction to Neutral.

## Fallback definition
Apply a Bear-side neutralizer only when all of the following are true:
- Base prediction is Bear
- RuleB raw warning is active
- Center Soft support is active

The action is to convert the Bear prediction to Neutral.

## Locked v273 summary
Winner metrics on the tested dataset:
- Directional Accuracy: 56.27%
- Directional Coverage: 36.65%
- Bear Precision: 55.38%
- Triggers: 8
- Good suppressions: 6
- Bad suppressions: 2
- Capture of wrong-Bear RuleB rows: 46.15%

Fallback metrics on the tested dataset:
- Directional Accuracy: 56.23%
- Directional Coverage: 36.86%
- Bear Precision: 55.32%
- Triggers: 6
- Good suppressions: 5
- Bad suppressions: 1
- Capture of wrong-Bear RuleB rows: 38.46%

## Files in this bundle
- offline_v273_rollout_comparison.py
- LOCKED_METHOD_v273_README_RECREATED.md
- LOCKED_METHOD_v273_SPEC_RECREATED.json

