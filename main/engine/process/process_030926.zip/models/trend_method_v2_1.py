from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

MODEL_ID = "trend_method_v2_1"

DEFAULT_CONFIG: Dict[str, Any] = {
    "model_id": MODEL_ID,
    "enabled": True,
    "description": "v2_1 replay model: Bull-run instability inversion built on top of v2_0 history state",
    "thresholds": {
        "flip_score_threshold": 0.18,
        "compression_velocity_min": 0.0,
        "ratio_max": -0.10,
        "alignment_max": 1.00,
    },
}


def _as_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(str(value).strip().replace("$", "").replace(",", ""))
    except Exception:
        return None


def _norm_direction(value: Any) -> str:
    txt = str(value or "").strip().lower()
    if txt in {"bull", "bullish", "up", "long", "+1", "1"}:
        return "Bull"
    if txt in {"bear", "bearish", "down", "short", "-1"}:
        return "Bear"
    return "Neutral"


def _get_signals_from_snapshot(snapshot: Mapping[str, Any]) -> Dict[str, Optional[float]]:
    debug = snapshot.get("debug") if isinstance(snapshot.get("debug"), Mapping) else {}
    signals = debug.get("signals") if isinstance(debug.get("signals"), Mapping) else {}
    raw = snapshot.get("raw_features_used") if isinstance(snapshot.get("raw_features_used"), Mapping) else {}

    fan_width = _as_float(signals.get("fan_width"))
    alignment = _as_float(signals.get("alignment"))
    compression_velocity = _as_float(signals.get("compression_velocity"))
    flip_score = _as_float(signals.get("flip_score"))
    slope_sum = _as_float(signals.get("slope_sum"))
    slope_magnitude = _as_float(signals.get("slope_magnitude"))
    ratio = _as_float(signals.get("ratio_8_23_to_23_53"))

    if slope_sum is None:
        s23 = _as_float(raw.get("s23")) or 0.0
        s53 = _as_float(raw.get("s53")) or 0.0
        slope_sum = s23 + s53
    if slope_magnitude is None:
        slope_magnitude = abs(slope_sum or 0.0)

    return {
        "fan_width": fan_width,
        "alignment": alignment,
        "compression_velocity": compression_velocity,
        "flip_score": flip_score,
        "slope_sum": slope_sum,
        "slope_magnitude": slope_magnitude,
        "ratio_8_23_to_23_53": ratio,
        "s23": _as_float(raw.get("s23")),
        "s53": _as_float(raw.get("s53")),
    }


def run_from_v2_snapshot(snapshot: Mapping[str, Any], config: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    """
    Replay v2_1 against a stored v2_0 history snapshot.

    The model keeps the original v2_0 decision unless the row matches the
    discovered Bull-run instability condition, in which case the call is
    inverted from Bull -> Bear.
    """
    cfg = dict(DEFAULT_CONFIG)
    if config:
        cfg.update(config)
        if isinstance(config.get("thresholds"), Mapping):
            merged_thr = dict(DEFAULT_CONFIG["thresholds"])
            merged_thr.update(config["thresholds"])
            cfg["thresholds"] = merged_thr

    thresholds = cfg["thresholds"]
    model_id = str(cfg.get("model_id") or MODEL_ID)

    baseline_trend = _norm_direction(snapshot.get("trend"))
    baseline_confidence = _as_float(snapshot.get("confidence")) or 1.0
    baseline_score = _as_float(snapshot.get("score")) or 0.0

    debug = snapshot.get("debug") if isinstance(snapshot.get("debug"), Mapping) else {}
    regime = str(debug.get("regime") or "UNKNOWN").upper()
    run_direction = _norm_direction(debug.get("run_direction"))

    signals = _get_signals_from_snapshot(snapshot)
    flip_score = signals["flip_score"] or 0.0
    compression_velocity = signals["compression_velocity"] or 0.0
    ratio = signals["ratio_8_23_to_23_53"]
    alignment = signals["alignment"]

    override = False
    reason = f"baseline={baseline_trend}|regime={regime}|flip_score={flip_score:.5f}"

    if (
        baseline_trend == "Bull"
        and regime == "RUN"
        and flip_score >= float(thresholds["flip_score_threshold"])
        and compression_velocity >= float(thresholds["compression_velocity_min"])
        and (ratio is None or ratio <= float(thresholds["ratio_max"]))
        and (alignment is None or alignment <= float(thresholds["alignment_max"]))
    ):
        override = True

    trend = "Bear" if override else baseline_trend
    if override:
        reason = (
            "bull_run_instability_inversion"
            f"|flip={flip_score:.5f}"
            f"|comp={compression_velocity:.5f}"
            f"|ratio={0.0 if ratio is None else ratio:.5f}"
            f"|align={0.0 if alignment is None else alignment:.5f}"
        )

    out_debug = {
        "baseline_model_id": str(snapshot.get("model_id") or "trend_method_v2_0"),
        "baseline_trend": baseline_trend,
        "override_applied": override,
        "regime": regime,
        "run_direction": run_direction,
        "thresholds": thresholds,
        "signals": {
            "fan_width": signals["fan_width"],
            "alignment": alignment,
            "compression_velocity": compression_velocity,
            "flip_score": flip_score,
            "slope_sum": signals["slope_sum"],
            "slope_magnitude": signals["slope_magnitude"],
            "ratio_8_23_to_23_53": ratio,
        },
    }

    raw_features_used = {
        "s23": signals["s23"],
        "s53": signals["s53"],
        "fan_width": signals["fan_width"],
        "alignment": alignment,
        "compression_velocity": compression_velocity,
        "flip_score": flip_score,
        "ratio_8_23_to_23_53": ratio,
    }

    return {
        "model_id": model_id,
        "trend": trend,
        "confidence": baseline_confidence,
        "score": baseline_score,
        "reason": reason,
        "debug": out_debug,
        "raw_features_used": raw_features_used,
    }
