from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

_HYST_TRACKER: Dict[str, Any] = {
    "episode_start_ts": None,
    "episode_pair": None,
    "last_primary_flip_ts": None,
    "leader_state": {},
}


# ======================================================================================
# PUBLIC EXPORTS (for DB_process_calc / DB_process_trend later)
# ======================================================================================

def get_hyst_tracker() -> Dict[str, Any]:
    """Phase 1: allow other modules to read tracker if needed."""
    return _HYST_TRACKER


# ======================================================================================
# SMALL NUMERIC HELPERS
# ======================================================================================

def _sign(x: float, eps: float = 1e-12) -> int:
    if x > eps:
        return 1
    if x < -eps:
        return -1
    return 0


def _mad(arr: np.ndarray) -> float:
    if arr.size == 0:
        return 0.0
    med = np.median(arr)
    return float(np.median(np.abs(arr - med)) + 1e-12)


def _percentile(arr: np.ndarray, p: float) -> float:
    if arr.size == 0:
        return 0.0
    return float(np.percentile(arr, p))


def _compute_slope(ts: List[datetime], vals: np.ndarray) -> float:
    """Simple linear slope vs seconds. vals may contain NaN (caller should pre-filter)."""
    if len(ts) < 5:
        return 0.0
    x = np.array([(t - ts[0]).total_seconds() for t in ts], dtype=float)
    y = vals.astype(float)
    if not np.isfinite(y).any():
        return 0.0
    # Filter NaNs
    m = np.isfinite(y)
    if m.sum() < 5:
        return 0.0
    x2 = x[m]
    y2 = y[m]
    try:
        return float(np.polyfit(x2, y2, 1)[0])
    except Exception:
        return 0.0


def _compute_accel(ts: List[datetime], vals: np.ndarray) -> float:
    """
    Quadratic acceleration vs seconds (2nd derivative).
    Uses y = a*x^2 + b*x + c => y'' = 2a.
    vals may contain NaN (caller may pass unfiltered).
    """
    if len(ts) < 7:
        return 0.0
    x = np.array([(t - ts[0]).total_seconds() for t in ts], dtype=float)
    y = vals.astype(float)
    if not np.isfinite(y).any():
        return 0.0
    m = np.isfinite(y)
    if m.sum() < 7:
        return 0.0
    x2 = x[m]
    y2 = y[m]
    try:
        a = float(np.polyfit(x2, y2, 2)[0])
        return float(2.0 * a)
    except Exception:
        return 0.0


def _find_last_sign_flip(ts: List[datetime], vals: np.ndarray) -> Optional[datetime]:
    """Find most recent index where sign changes between two adjacent non-zero signs."""
    if len(ts) < 3 or vals.size < 3:
        return None
    signs = np.array([_sign(v) for v in vals], dtype=int)
    for i in range(len(signs) - 1, 0, -1):
        a = signs[i - 1]
        b = signs[i]
        if a != 0 and b != 0 and a != b:
            return ts[i]
    return None


def _nearest_align(
        base_ts: List[datetime],
        other_ts: List[datetime],
        other_vals: np.ndarray,
        tol_seconds: float = 3.0,
) -> np.ndarray:
    """
    Nearest neighbor alignment (Phase 1).
    Returns array aligned to base_ts; NaN if no match within tolerance.
    """
    out = np.full(len(base_ts), np.nan, dtype=float)
    if len(base_ts) == 0 or len(other_ts) == 0:
        return out

    j = 0
    for i, t in enumerate(base_ts):
        best_k = None
        best_dt = None

        # Move j forward while other_ts[j] is behind t (small optimization)
        while j + 1 < len(other_ts) and other_ts[j + 1] <= t:
            j += 1

        # Check around j (j and j+1) for nearest
        for k in (j, j + 1):
            if 0 <= k < len(other_ts):
                dt = abs((other_ts[k] - t).total_seconds())
                if best_dt is None or dt < best_dt:
                    best_dt = dt
                    best_k = k

        if best_k is not None and best_dt is not None and best_dt <= tol_seconds:
            out[i] = float(other_vals[best_k])

    return out


# ======================================================================================
# CORE FEATURE BUILDER (NO TREND DECISION)
# ======================================================================================

def compute_hysteresis_features(
        per_sigma_hist: Dict[int, Dict[str, Any]],
        decision_dt: datetime,
        lookback_seconds: int = 3600,
        tail_seconds: int = 120,
        align_tol_seconds: float = 3.0,
        primary_default: Tuple[int, int] = (38, 83),
        primary_slow: Tuple[int, int] = (53, 83),
        probe_pair: Tuple[int, int] = (23, 83),
) -> Dict[str, Any]:
    """
    Compute hysteresis episode + ladder stack metrics.
    DOES NOT produce Bull/Bear/Neutral or confidence.
    Returns a hyst_obj dict usable by trend/calc modules.
    """

    # ---- basic guards
    required = {23, 38, 53, 68, 83}
    missing = sorted([s for s in required if s not in per_sigma_hist])
    if missing:
        return {
            "meta": {
                "skipped": True,
                "skip_reason": f"missing_sigmas:{missing}",
                "missing_sigmas": missing,
            }
        }

    def _series(sigma: int) -> Tuple[List[datetime], np.ndarray]:
        ts = per_sigma_hist[sigma]["ts"]
        vals = np.array(per_sigma_hist[sigma]["values"], dtype=float)
        return ts, vals

    # base grid = g83 timestamps (slowest)
    ts83, g83 = _series(83)

    # baseline window mask
    cutoff = decision_dt - timedelta(seconds=lookback_seconds)
    mask_base = np.array([t >= cutoff for t in ts83], dtype=bool)

    # ---- choose primary pair (38,83) unless no crossing seen in lookback -> (53,83)
    mode = "DEFAULT"
    pair = primary_default

    def _d_pair(a: int, b: int) -> Tuple[np.ndarray, Optional[datetime]]:
        ts_a, g_a = _series(a)
        g_a_al = _nearest_align(ts83, ts_a, g_a, tol_seconds=align_tol_seconds)
        d = g_a_al - g83  # b assumed 83 base here
        last_flip = _find_last_sign_flip(ts83, d[mask_base])
        # last_flip found in masked array uses masked indices; simplest: recompute on full array:
        last_flip_full = _find_last_sign_flip(ts83, d)
        return d, last_flip_full

    d38_83, last_flip_38 = _d_pair(38, 83)

    # "slow switch": if there is no recent crossing (within lookback), we use (53,83)
    # We approximate that by: no crossing found at all OR last_flip is older than cutoff.
    if last_flip_38 is None or last_flip_38 < cutoff:
        d53_83, last_flip_53 = _d_pair(53, 83)
        if last_flip_53 is not None:
            pair = primary_slow
            d_primary = d53_83
            last_cross = last_flip_53
            mode = "SLOW_SWITCH"
        else:
            d_primary = d38_83
            last_cross = last_flip_38
    else:
        d_primary = d38_83
        last_cross = last_flip_38

    # Episode start anchor = last crossing within lookback if available
    start_ts = last_cross if (last_cross is not None and last_cross >= cutoff) else None
    elapsed = (decision_dt - start_ts).total_seconds() if start_ts else None
    stage = "IN_PROGRESS"  # true stage classification belongs in DB_process_trend/calc

    # ---- probe pair (23,83) flags (no trend decision, only signals)
    ts23, g23 = _series(probe_pair[0])
    g23_al = _nearest_align(ts83, ts23, g23, tol_seconds=align_tol_seconds)
    d23_83 = g23_al - g83
    probe_last_flip = _find_last_sign_flip(ts83, d23_83)

    flip_watch = False
    if start_ts and probe_last_flip and probe_last_flip > start_ts:
        # probe flipped after episode start (primary not necessarily ended yet)
        flip_watch = True

    # fast collapse flag (simple Phase 1 proxy): |d_probe| slope strongly negative over tail
    tail_cut = decision_dt - timedelta(seconds=tail_seconds)
    mask_tail = np.array([t >= tail_cut for t in ts83], dtype=bool)
    ts_tail = [ts83[i] for i in range(len(ts83)) if mask_tail[i]]
    dprobe_tail = np.abs(d23_83[mask_tail])
    dprobe_slope = _compute_slope(ts_tail, dprobe_tail)  # negative means collapsing
    fast_collapse = bool(dprobe_slope < 0)

    # ---- ladder stacks metrics (raw features; no vote/fusion)
    ladder_defs = {
        "S0": [23, 38, 53, 68, 83],
        "S1": [38, 53, 68, 83],
        "S2": [53, 68, 83],
        "S3": [68, 83],
    }

    stacks: Dict[str, Any] = {}
    for sid, sigs in ladder_defs.items():
        series_map = {}
        for s in sigs:
            ts_s, g_s = _series(s)
            series_map[s] = _nearest_align(ts83, ts_s, g_s, tol_seconds=align_tol_seconds)

        vals_stack = np.vstack([series_map[s] for s in sigs])  # shape: (k, n)
        mean_curve = np.nanmean(vals_stack, axis=0)

        # tail series
        mean_tail = mean_curve[mask_tail]
        m = _compute_slope(ts_tail, mean_tail)
        m2 = _compute_accel(ts_tail, mean_tail)

        # baseline drift scale (MAD of mean curve changes over baseline)
        mean_base = mean_curve[mask_base]
        m_scale = _mad(mean_base)
        m_norm = float(m / (m_scale + 1e-12)) if np.isfinite(m_scale) else 0.0
        m2_norm = float(m2 / (m_scale + 1e-12)) if np.isfinite(m_scale) else 0.0

        # spread series
        spread_series = np.nanmax(vals_stack, axis=0) - np.nanmin(vals_stack, axis=0)
        W_now = float(spread_series[-1]) if np.isfinite(spread_series[-1]) else float("nan")

        spread_base = spread_series[mask_base]
        W_p25 = _percentile(spread_base, 25)
        W_p75 = _percentile(spread_base, 75)

        W_med = float(np.median(spread_base)) if spread_base.size else 0.0
        W_mad = _mad(spread_base)
        W_z = float((W_now - W_med) / (W_mad + 1e-12)) if np.isfinite(W_now) else float("nan")
        W_ratio = float(W_now / (W_p75 + 1e-12)) if np.isfinite(W_now) else float("nan")

        # percentile position (0..100) of current W vs baseline
        if spread_base.size > 10 and np.isfinite(W_now):
            W_pct = float(np.mean(spread_base <= W_now) * 100.0)
        else:
            W_pct = float("nan")

        # spread velocity on tail
        spread_tail = spread_series[mask_tail]
        dW = _compute_slope(ts_tail, spread_tail)
        ddW = _compute_accel(ts_tail, spread_tail)

        dW_scale = _mad(spread_base)
        dW_norm = float(dW / (dW_scale + 1e-12)) if np.isfinite(dW_scale) else 0.0
        ddW_norm = float(ddW / (dW_scale + 1e-12)) if np.isfinite(dW_scale) else 0.0

        # order scores (adjacent inequalities at last point)
        last_vals = vals_stack[:, -1]
        # need all finite to assess order reliably
        if np.all(np.isfinite(last_vals)):
            bull_ok = np.all(np.diff(last_vals) < 0)  # g_fastest > g_next > ...
            bear_ok = np.all(np.diff(last_vals) > 0)
            order_bull = 1.0 if bull_ok else 0.0
            order_bear = 1.0 if bear_ok else 0.0

            # dominance / leaders (captures "G83 on top vs bottom" style polarity)
            idx_max = int(np.argmax(last_vals))
            idx_min = int(np.argmin(last_vals))
            leader_max_sigma = int(sigs[idx_max])
            leader_min_sigma = int(sigs[idx_min])
            dom = float((np.nanmax(last_vals) - np.nanmin(last_vals)) / (m_scale + 1e-12))
        else:
            order_bull = 0.0
            order_bear = 0.0
            leader_max_sigma = None
            leader_min_sigma = None
            dom = 0.0

        # simple cross-rate: count sign flips in adjacent differences over tail
        cross_count = 0
        pairs = list(zip(sigs[:-1], sigs[1:]))
        cross_pairs: Dict[str, Any] = {}
        for a, b in pairs:
            da = series_map[a][mask_tail] - series_map[b][mask_tail]
            sgn = np.array([_sign(x) for x in da], dtype=int)
            # count non-zero sign changes
            c = 0
            last_flip_ts = None
            for i in range(1, len(sgn)):
                if sgn[i] != 0 and sgn[i - 1] != 0 and sgn[i] != sgn[i - 1]:
                    cross_count += 1
                    c += 1
                    if i < len(ts_tail):
                        last_flip_ts = ts_tail[i]
            cross_pairs[f"{a}-{b}"] = {"count": int(c), "last_flip_ts": last_flip_ts}
        tail_minutes = max(tail_seconds / 60.0, 1e-9)
        cross_rate = float(cross_count / tail_minutes)

        # stability proxy: 1/(1+cross_rate)
        order_stability = float(1.0 / (1.0 + cross_rate))
        eff_order = float(max(order_bull, order_bear) * order_stability)

        # "ok" threshold for eff_order relative to baseline (p60 of eff_order baseline)
        # Phase 1 baseline: approximate using spread tightness as proxy when computing eff_order history is expensive
        # -> return eff_order + let trend/calc decide thresholds using full baseline later
        eff_order_ok = None  # leave decision to DB_process_trend/calc

        stacks[sid] = {
            "sigmas": sigs,
            "m": float(m),
            "m_norm": float(m_norm),
            "m2": float(m2),
            "m2_norm": float(m2_norm),
            "W_now": W_now,
            "W_pct": W_pct,
            "W_p25": W_p25,
            "W_p75": W_p75,
            "W_med": float(W_med),
            "W_mad": float(W_mad),
            "W_z": float(W_z),
            "W_ratio": float(W_ratio),
            "dW": float(dW),
            "dW_norm": float(dW_norm),
            "ddW": float(ddW),
            "ddW_norm": float(ddW_norm),
            "order_bull": float(order_bull),
            "order_bear": float(order_bear),
            "order_stability": float(order_stability),
            "eff_order": float(eff_order),
            "eff_order_ok": eff_order_ok,
            "cross_rate": float(cross_rate),
            "cross_pairs": cross_pairs,
            "dom": float(dom),
            "leader_max_sigma": leader_max_sigma,
            "leader_min_sigma": leader_min_sigma,
            "valid": True,
            "notes": "",
        }

    # ---- optional ETA metric (purely descriptive, not a decision)
    # Use S1 by default as a stable source for collapse ETA if dW < 0 and W meaningful
    eta_to_end_seconds = None
    eta_source = None
    s1 = stacks.get("S1")
    if s1 and np.isfinite(s1["W_now"]) and s1["dW"] < 0:
        eta_to_end_seconds = float(abs(s1["W_now"] / max(abs(s1["dW"]), 1e-12)))
        eta_source = "S1"

    hyst_obj = {
        "method_id": "method_hyster_v1.0",
        "episode": {
            "pair_used": [pair[0], pair[1]],
            "mode": mode,
            "lookback_seconds": lookback_seconds,
            "start_ts": start_ts,
            "last_cross_ts": last_cross,
            "elapsed_seconds": elapsed,
            "stage": stage,
            "d_now": float(d_primary[-1]) if d_primary.size else float("nan"),
            "sign_now": int(_sign(float(d_primary[-1]))) if d_primary.size else 0,
        },
        "probe": {
            "pair": [probe_pair[0], probe_pair[1]],
            "d_now": float(d23_83[-1]) if d23_83.size else float("nan"),
            "sign_now": int(_sign(float(d23_83[-1]))) if d23_83.size else 0,
            "flip_watch": bool(flip_watch),
            "fast_collapse": bool(fast_collapse),
            "d_abs_slope_tail": float(dprobe_slope),
            "last_flip_ts": probe_last_flip,
        },
        "eta": {
            "eta_to_end_seconds": eta_to_end_seconds,
            "source_stack": eta_source,
        },
        "stacks": stacks,
        "meta": {
            "decision_time": decision_dt,
            "tail_window_seconds": tail_seconds,
            "baseline_window_seconds": lookback_seconds,
            "align_tol_seconds": align_tol_seconds,
            "missing_sigmas": [],
            "skipped": False,
            "skip_reason": None,
        }
    }

    return hyst_obj


# ======================================================================================
# PRINTING ENTRYPOINT (LOG-ONLY)
# ======================================================================================




def _safe_seconds_between(later: Any, earlier: Any) -> Optional[float]:
    try:
        if later is None or earlier is None:
            return None
        if isinstance(later, datetime) and isinstance(earlier, datetime):
            return float((later - earlier).total_seconds())
    except Exception:
        return None
    return None


def flatten_hysteresis_to_src(
    hyst_obj: dict,
    config: Optional[dict] = None,
) -> dict:
    """Flatten live hysteresis payload into canonical src_hyst_* columns."""
    out: Dict[str, Any] = {}

    episode = hyst_obj.get("episode", {}) or {}
    probe = hyst_obj.get("probe", {}) or {}
    eta = hyst_obj.get("eta", {}) or {}
    stacks = hyst_obj.get("stacks", {}) or {}
    meta = hyst_obj.get("meta", {}) or {}

    decision_time = meta.get("decision_time")
    last_cross_ts = episode.get("last_cross_ts")

    out["src_hyst_primary_sign"] = episode.get("sign_now")
    out["src_hyst_episode_age_sec"] = episode.get("elapsed_seconds")
    out["src_hyst_last_cross_age_sec"] = _safe_seconds_between(decision_time, last_cross_ts)

    out["src_hyst_probe_sign"] = probe.get("sign_now")
    out["src_hyst_probe_flip_watch"] = probe.get("flip_watch")
    out["src_hyst_fast_collapse"] = probe.get("fast_collapse")

    out["src_hyst_eta_to_end_seconds"] = eta.get("eta_to_end_seconds")

    for stack_name in ["S0", "S1", "S2", "S3"]:
        s = stacks.get(stack_name, {}) or {}
        base = f"src_hyst_{stack_name.lower()}"
        out[f"{base}_state"] = s.get("state")
        out[f"{base}_pressure"] = s.get("pressure")
        out[f"{base}_risk"] = s.get("risk")
        out[f"{base}_stability"] = s.get("stability")
        out[f"{base}_near_cross"] = s.get("near_cross")
        out[f"{base}_spread_slope"] = s.get("spread_slope")
        out[f"{base}_spread_accel"] = s.get("spread_accel")

    out["src_hyst_leader_max_sigma"] = meta.get("leader_max_sigma")
    out["src_hyst_leader_min_sigma"] = meta.get("leader_min_sigma")
    out["src_hyst_cross_rate"] = meta.get("cross_rate")
    out["src_hyst_order_stability"] = meta.get("order_stability")
    out["src_hyst_ladder_monotonic"] = meta.get("ladder_monotonic")
    out["src_hyst_ladder_compression"] = meta.get("ladder_compression")

    return out
